from flask import Flask, render_template, request, redirect
from models import db, User, Feedback
from sentiment import analyze_sentiment
from flask_login import LoginManager, login_user, logout_user, login_required

app = Flask(__name__)
app.secret_key = "secret"

# Database Config
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///database.db'
db.init_app(app)

# Login Manager
login_manager = LoginManager()
login_manager.init_app(app)

@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

# ✅ FIX: Create DB (Flask latest version compatible)
with app.app_context():
    db.create_all()

# -------- LOGIN --------
@app.route('/', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        user = User.query.filter_by(username=request.form['username']).first()
        if user and user.password == request.form['password']:
            login_user(user)
            return redirect('/dashboard')
    return render_template('login.html')

# -------- REGISTER --------
@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        user = User(username=request.form['username'], password=request.form['password'])
        db.session.add(user)
        db.session.commit()
        return redirect('/')
    return render_template('register.html')

# -------- LOGOUT --------
@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect('/')

# -------- DASHBOARD --------
@app.route('/dashboard')
@login_required
def dashboard():
    feedbacks = Feedback.query.all()

    pos = sum(1 for f in feedbacks if f.sentiment == "Positive")
    neg = sum(1 for f in feedbacks if f.sentiment == "Negative")
    neu = sum(1 for f in feedbacks if f.sentiment == "Neutral")

    # Latest feedback for emoji mood
    latest = feedbacks[-1].sentiment if feedbacks else "Neutral"

    return render_template(
        'dashboard.html',
        pos=pos,
        neg=neg,
        neu=neu,
        latest=latest,
        feedbacks=feedbacks
    )

# -------- FEEDBACK --------
@app.route('/feedback', methods=['GET', 'POST'])
@login_required
def feedback():
    if request.method == 'POST':
        text = request.form['feedback']
        sentiment = analyze_sentiment(text)

        fb = Feedback(text=text, sentiment=sentiment)
        db.session.add(fb)
        db.session.commit()

        # Smart Alert
        if sentiment == "Negative":
            print("⚠️ ALERT: Negative Feedback Detected!")

        return redirect('/dashboard')

    return render_template('feedback.html')

# -------- RUN APP --------
if __name__ == "__main__":
    app.run(debug=True)